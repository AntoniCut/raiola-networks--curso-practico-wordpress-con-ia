<?php

// SPDX-FileCopyrightText: 2026 Ovation S.r.l. <dev@novamira.ai>
// SPDX-License-Identifier: AGPL-3.0-or-later

declare(strict_types=1);

namespace Novamira\Abilities\Gutenberg;

use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) {
    exit();
}

add_action('rest_api_init', __NAMESPACE__ . '\\register_rest_routes');

function register_rest_routes(): void
{
    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/batches', args: [
        'methods' => 'GET',
        'callback' => __NAMESPACE__ . '\\rest_list_batches',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_dashboard',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/finalizer-runtime/heartbeat', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_finalizer_runtime_heartbeat',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_dashboard',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/finalizer-runtime/status', args: [
        'methods' => 'GET',
        'callback' => __NAMESPACE__ . '\\rest_poll_finalizer_runtime_status',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_poll_finalizer_runtime',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/finalizer-runtime/events', args: [
        'methods' => 'GET',
        'callback' => __NAMESPACE__ . '\\rest_stream_finalizer_runtime_events',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_poll_finalizer_runtime',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/batches/(?P<batch_id>\d+)/claim', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_claim_batch',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_batch',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/batches/claim-next', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_claim_next_batch',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_dashboard',
    ]);

    register_rest_route(
        route_namespace: 'novamira/v1',
        route: '/gutenberg/batches/(?P<batch_id>\d+)/items/claim-next',
        args: [
            'methods' => 'POST',
            'callback' => __NAMESPACE__ . '\\rest_claim_next_item',
            'permission_callback' => __NAMESPACE__ . '\\rest_can_access_batch',
        ],
    );

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/items/(?P<item_id>\d+)/spec', args: [
        'methods' => 'GET',
        'callback' => __NAMESPACE__ . '\\rest_get_item_spec',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_item',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/items/(?P<item_id>\d+)/complete', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_complete_item',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_item',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/items/(?P<item_id>\d+)/fail', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_fail_item',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_item',
    ]);

    register_rest_route(route_namespace: 'novamira/v1', route: '/gutenberg/batches/(?P<batch_id>\d+)/cancel', args: [
        'methods' => 'POST',
        'callback' => __NAMESPACE__ . '\\rest_cancel_batch',
        'permission_callback' => __NAMESPACE__ . '\\rest_can_access_batch',
    ]);
}

function rest_can_access_dashboard(): bool|WP_Error
{
    if (!novamira_current_user_can_manage()) {
        return new WP_Error('rest_forbidden', 'You are not allowed to access the Block Editor Queue dashboard.', [
            'status' => 403,
        ]);
    }

    return true;
}

function rest_can_poll_finalizer_runtime(WP_REST_Request $request): bool|WP_Error
{
    $batch_id = rest_query_int_param($request, name: 'batch_id');
    $expires = rest_query_int_param($request, name: 'expires');
    $token = rest_query_string_param($request, name: 'token');
    if ($expires > 0 && $expires < time()) {
        return rest_finalizer_status_url_expired_error();
    }
    if (!finalizer_runtime_url_is_valid($batch_id, $expires, $token)) {
        return new WP_Error(
            'rest_forbidden',
            'The Block Editor Queue status URL is invalid. Call novamira/gutenberg-get-pending-batch for the batch, or novamira/gutenberg-get-finalizer-runtime when no batch is involved, to get a new sse_url and poll_url.',
            ['status' => 403],
        );
    }

    return true;
}

function rest_finalizer_status_url_expired_error(): WP_Error
{
    return new WP_Error(
        'gutenberg_finalizer_status_url_expired',
        'This Block Editor Queue status URL has expired. Call novamira/gutenberg-get-pending-batch for the batch, or novamira/gutenberg-get-finalizer-runtime when no batch is involved, to get a new sse_url and poll_url.',
        ['status' => 403],
    );
}

function rest_can_access_batch(WP_REST_Request $request): bool|WP_Error
{
    if (!novamira_current_user_can_manage()) {
        return new WP_Error('rest_forbidden', 'You are not allowed to finalize Gutenberg batches.', [
            'status' => 403,
        ]);
    }

    $batch_id = rest_int_param($request, name: 'batch_id');
    $batch = find_batch($batch_id);
    if (!$batch instanceof WP_Post) {
        return new WP_Error('gutenberg_batch_not_found', sprintf('Gutenberg batch %d was not found.', $batch_id), [
            'status' => 404,
        ]);
    }

    return true;
}

function rest_can_access_item(WP_REST_Request $request): bool|WP_Error
{
    if (!novamira_current_user_can_manage()) {
        return new WP_Error('rest_forbidden', 'You are not allowed to finalize Gutenberg items.', [
            'status' => 403,
        ]);
    }

    $item_id = rest_int_param($request, name: 'item_id');
    $item = find_item($item_id);
    if (!$item instanceof WP_Post) {
        return new WP_Error('gutenberg_item_not_found', sprintf('Gutenberg item %d was not found.', $item_id), [
            'status' => 404,
        ]);
    }

    return true;
}

function rest_int_param(WP_REST_Request $request, string $name): int
{
    $params = $request->get_params();
    if (!array_key_exists($name, $params)) {
        return 0;
    }

    return is_scalar($params[$name]) ? (int) $params[$name] : 0;
}

function rest_query_int_param(WP_REST_Request $request, string $name): int
{
    $params = $request->get_query_params();
    if (!array_key_exists($name, $params)) {
        return 0;
    }

    return is_scalar($params[$name]) ? (int) $params[$name] : 0;
}

function rest_query_string_param(WP_REST_Request $request, string $name): string
{
    $params = $request->get_query_params();
    if (!array_key_exists($name, $params)) {
        return '';
    }

    return is_scalar($params[$name]) ? (string) $params[$name] : '';
}

/** @return WP_REST_Response|WP_Error */
function rest_response(array|WP_Error $value): WP_REST_Response|WP_Error
{
    if (is_wp_error($value)) {
        return $value;
    }

    return new WP_REST_Response($value);
}

/** @return WP_REST_Response|WP_Error */
function rest_list_batches(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    mark_stale_drafts();

    $query_params = $request->get_query_params();
    $statuses = rest_string_list_query_param($query_params['status'] ?? null);
    $batches = get_batches($statuses !== [] ? $statuses : null, posts_per_page: 50);
    $visible_batches = [];
    foreach ($batches as $batch) {
        $batch = refresh_batch_runtime_state($batch);
        $visible_batches[] = shape_batch_summary($batch);
    }

    return new WP_REST_Response([
        'batches' => $visible_batches,
        'finalizer_runtime' => finalizer_runtime_status(),
    ]);
}

/** @return WP_REST_Response|WP_Error */
function rest_finalizer_runtime_heartbeat(): WP_REST_Response|WP_Error
{
    return new WP_REST_Response(record_finalizer_runtime_heartbeat());
}

/** @return WP_REST_Response|WP_Error */
function rest_poll_finalizer_runtime_status(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    finalizer_runtime_url_expiry(rest_query_int_param($request, name: 'expires'));

    return rest_response(rest_finalizer_runtime_status_payload(rest_query_int_param($request, name: 'batch_id')));
}

function rest_stream_finalizer_runtime_events(WP_REST_Request $request): void
{
    $batch_id = rest_query_int_param($request, name: 'batch_id');
    $expires = finalizer_runtime_url_expiry(rest_query_int_param($request, name: 'expires'));
    $requested_interval = rest_query_int_param($request, name: 'interval');
    $requested_duration = rest_query_int_param($request, name: 'duration');
    $interval = max(1, min(10, $requested_interval > 0 ? $requested_interval : 2));
    $duration = max(5, min(25, $requested_duration > 0 ? $requested_duration : 25));
    $started_at = time();

    rest_send_sse_headers();
    echo 'retry: ' . (string) ($interval * 1000) . "\n\n";
    rest_flush_sse();

    while (!connection_aborted()) {
        if ($expires < time()) {
            $expired = rest_finalizer_status_url_expired_error();
            rest_sse_event('error', [
                'code' => $expired->get_error_code(),
                'message' => $expired->get_error_message(),
            ]);
            exit();
        }

        $payload = rest_finalizer_runtime_status_payload($batch_id);
        if (is_wp_error($payload)) {
            rest_sse_event('error', [
                'code' => $payload->get_error_code(),
                'message' => $payload->get_error_message(),
            ]);
            exit();
        }

        rest_sse_event('status', $payload);
        if (rest_finalizer_runtime_payload_is_terminal($payload)) {
            rest_sse_event('done', ['reason' => 'terminal']);
            exit();
        }

        if ((time() - $started_at + $interval) >= $duration) {
            rest_sse_event('reconnect', [
                'reason' => 'connection_duration_limit',
                'after_seconds' => 1,
            ]);
            exit();
        }

        sleep($interval);
    }

    exit();
}

/**
 * @return array<string, mixed>|WP_Error
 */
function rest_finalizer_runtime_status_payload(int $batch_id): array|WP_Error
{
    mark_stale_drafts();

    if ($batch_id <= 0) {
        return [
            'finalizer_runtime' => finalizer_runtime_status(),
            'user_instruction' => finalizer_runtime_startup_instruction(),
        ];
    }

    $batch = find_batch($batch_id);
    if (!$batch instanceof WP_Post) {
        return new WP_Error('gutenberg_batch_not_found', sprintf('Gutenberg batch %d was not found.', $batch_id), [
            'status' => 404,
        ]);
    }

    $batch = refresh_batch_runtime_state($batch);
    if (!novamira_current_user_can_manage()) {
        return rest_untitled_batch_status_payload($batch);
    }

    return [
        'batch' => shape_batch($batch),
        'finalizer_runtime' => finalizer_runtime_status($batch),
        'user_instruction' => user_instruction($batch),
    ];
}

/**
 * The batch status for a request authorized by the URL token alone: statuses, counts and error codes, without
 * the batch label, the agent note, target titles, change summaries or error messages. The
 * gutenberg-get-pending-batch ability returns the full batch.
 *
 * @return array<string, mixed>
 */
function rest_untitled_batch_status_payload(WP_Post $batch): array
{
    $untitled = clone $batch;
    $untitled->post_title = '';
    $untitled->post_excerpt = '';

    $shaped = shape_batch($untitled);
    unset($shaped['last_error']);
    $shaped['details_ability'] = 'novamira/gutenberg-get-pending-batch';
    /** @var list<array<string, mixed>> $items */
    $items = is_array($shaped['items'] ?? null) ? $shaped['items'] : [];
    $shaped['items'] = array_map(
        static function (array $item): array {
            unset($item['target_title'], $item['change_summary']);
            /** @var list<array<string, mixed>> $rows */
            $rows = is_array($item['validation_errors'] ?? null) ? $item['validation_errors'] : [];
            $item['validation_errors'] = array_map(static function (array $row): array {
                unset($row['target_title'], $row['message']);
                return $row;
            }, $rows);
            return $item;
        },
        $items,
    );

    return [
        'batch' => $shaped,
        'finalizer_runtime' => finalizer_runtime_status($untitled),
        'user_instruction' => user_instruction($untitled),
    ];
}

/**
 * @param array<string, mixed> $payload
 */
function rest_finalizer_runtime_payload_is_terminal(array $payload): bool
{
    $batch = is_array($payload['batch'] ?? null) ? $payload['batch'] : null;
    if ($batch === null || !is_scalar($batch['status'] ?? null)) {
        return false;
    }

    return in_array(
        (string) $batch['status'],
        [
            STATUS_FINALIZED,
            STATUS_FAILED,
            STATUS_CONFLICTED,
            STATUS_CANCELED,
            STATUS_STALE,
        ],
        strict: true,
    );
}

function rest_send_sse_headers(): void
{
    if (!headers_sent()) {
        status_header(200);
        header('Content-Type: text/event-stream; charset=UTF-8');
        header('Cache-Control: no-cache, no-transform');
        header('X-Accel-Buffering: no');
        header('Connection: keep-alive');
    }
}

/**
 * @param array<string, mixed> $data
 */
function rest_sse_event(string $event, array $data): void
{
    $json = wp_json_encode($data, JSON_UNESCAPED_SLASHES);
    echo 'event: ' . $event . "\n";
    echo 'data: ' . ($json !== false ? $json : '{}') . "\n\n";
    rest_flush_sse();
}

function rest_flush_sse(): void
{
    if (ob_get_level() > 0) {
        ob_flush();
    }

    flush();
}

/** @return WP_REST_Response|WP_Error */
function rest_claim_batch(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    return rest_response(claim_batch(rest_int_param($request, name: 'batch_id')));
}

/** @return WP_REST_Response|WP_Error */
function rest_claim_next_batch(): WP_REST_Response|WP_Error
{
    mark_stale_drafts();

    // Query ready work separately so newer retries cannot fill its candidate window.
    foreach ([[STATUS_READY], [STATUS_FAILED, STATUS_RUNNING]] as $statuses) {
        foreach (get_batches($statuses, posts_per_page: 50) as $batch) {
            $batch = refresh_batch_runtime_state($batch);
            $claim = claim_batch($batch->ID);
            if (!is_wp_error($claim)) {
                return new WP_REST_Response([
                    'done' => false,
                    'claim' => $claim,
                ]);
            }

            if (in_array(
                $claim->get_error_code(),
                ['gutenberg_batch_claim_raced', 'gutenberg_batch_not_claimable'],
                strict: true,
            )) {
                continue;
            }

            return $claim;
        }
    }

    return new WP_REST_Response(['done' => true]);
}

/** @return WP_REST_Response|WP_Error */
function rest_claim_next_item(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    $params = rest_json_params($request);
    if (is_wp_error($params)) {
        return rest_response($params);
    }

    $lease_owner = is_scalar($params['lease_owner'] ?? null) ? (string) $params['lease_owner'] : '';

    return rest_response(claim_next_item(rest_int_param($request, name: 'batch_id'), $lease_owner));
}

/** @return WP_REST_Response|WP_Error */
function rest_get_item_spec(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    $item_id = rest_int_param($request, name: 'item_id');
    $item = find_item($item_id);
    if (!$item instanceof WP_Post) {
        return new WP_Error('gutenberg_item_not_found', sprintf('Gutenberg item %d was not found.', $item_id), [
            'status' => 404,
        ]);
    }

    $query_params = $request->get_query_params();
    $lease_owner = array_key_exists('lease_owner', $query_params) && is_scalar($query_params['lease_owner'])
        ? (string) $query_params['lease_owner']
        : '';
    if (status($item->ID) !== STATUS_RUNNING || !lease_is_valid($item->ID, $lease_owner)) {
        return new WP_Error('gutenberg_item_lease_invalid', 'The item finalization lease is no longer active.', [
            'status' => 409,
        ]);
    }

    $blocks = item_blocks($item);
    if (is_wp_error($blocks)) {
        return $blocks;
    }

    $editor_url = rest_item_editor_url($item);
    if (is_wp_error($editor_url)) {
        return $editor_url;
    }

    return new WP_REST_Response([
        'item' => shape_item($item),
        'blocks' => $blocks,
        'editor_url' => $editor_url,
    ]);
}

/** @return string|WP_Error */
function rest_item_editor_url(WP_Post $item): string|WP_Error
{
    $target_id = meta_int($item->ID, META_TARGET_ID);
    $target = get_target($target_id);
    if (!$target instanceof WP_Post) {
        return new WP_Error('gutenberg_target_not_found', sprintf('Target post %d was not found.', $target_id), [
            'status' => 404,
        ]);
    }

    $editor_url = get_edit_post_link($target_id, context: 'raw');
    if (!is_string($editor_url) || $editor_url === '') {
        $editor_url = admin_url(sprintf('post.php?post=%d&action=edit', $target_id));
    }

    return add_query_arg([
        'novamira_gb_finalizer' => '1',
        'novamira_gb_item' => $item->ID,
    ], $editor_url);
}

/** @return WP_REST_Response|WP_Error */
function rest_complete_item(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    $params = rest_json_params($request);
    if (is_wp_error($params)) {
        return rest_response($params);
    }

    $lease_owner = is_scalar($params['lease_owner'] ?? null) ? (string) $params['lease_owner'] : '';
    $content = is_scalar($params['content'] ?? null) ? (string) $params['content'] : '';
    $serialization_runtime = is_scalar($params['serialization_runtime'] ?? null)
        ? (string) $params['serialization_runtime']
        : '';
    $serialization_runtime_reason = is_scalar($params['serialization_runtime_reason'] ?? null)
        ? (string) $params['serialization_runtime_reason']
        : '';

    return rest_response(complete_item(
        rest_int_param($request, name: 'item_id'),
        $lease_owner,
        $content,
        $params['validations'] ?? null,
        [
            'runtime' => $serialization_runtime,
            'reason' => $serialization_runtime_reason,
        ],
    ));
}

/** @return WP_REST_Response|WP_Error */
function rest_fail_item(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    $params = rest_json_params($request);
    if (is_wp_error($params)) {
        return rest_response($params);
    }

    $lease_owner = is_scalar($params['lease_owner'] ?? null) ? (string) $params['lease_owner'] : '';
    $message = is_scalar($params['message'] ?? null) ? (string) $params['message'] : '';
    $serialization_runtime = is_scalar($params['serialization_runtime'] ?? null)
        ? (string) $params['serialization_runtime']
        : '';
    $serialization_runtime_reason = is_scalar($params['serialization_runtime_reason'] ?? null)
        ? (string) $params['serialization_runtime_reason']
        : '';

    return rest_response(fail_item(
        rest_int_param($request, name: 'item_id'),
        $lease_owner,
        $params['errors'] ?? null,
        message: $message,
        serialization: [
            'runtime' => $serialization_runtime,
            'reason' => $serialization_runtime_reason,
        ],
    ));
}

/** @return WP_REST_Response|WP_Error */
function rest_cancel_batch(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    return rest_response(cancel_batch(rest_int_param($request, name: 'batch_id')));
}

/**
 * @return array<string, mixed>|WP_Error
 */
function rest_json_params(WP_REST_Request $request): array|WP_Error
{
    $raw_params = $request->get_json_params();
    // @mago-expect analysis:redundant-type-comparison -- The WordPress stub is narrower than the runtime contract.
    // @mago-expect analysis:impossible-condition -- The WordPress stub is narrower than the runtime contract.
    if (!is_array($raw_params)) {
        return new WP_Error('rest_missing_json_body', 'Send a JSON object body with Content-Type: application/json.', [
            'status' => 400,
        ]);
    }

    $params = array_filter(
        $raw_params,
        static fn(mixed $value, mixed $key): bool => is_string($key),
        ARRAY_FILTER_USE_BOTH,
    );

    /** @var array<string, mixed> $params */
    return typed_string_map($params);
}

/**
 * @return list<string>
 */
function rest_string_list_query_param(mixed $value): array
{
    if (is_string($value)) {
        return array_values(array_filter(
            array_map(static fn(string $item): string => trim($item), explode(',', $value)),
            static fn(string $item): bool => $item !== '',
        ));
    }

    if (!is_array($value)) {
        return [];
    }

    return array_values(array_filter(
        array_map(static fn(mixed $item): string => is_scalar($item) ? trim((string) $item) : '', $value),
        static fn(string $item): bool => $item !== '',
    ));
}
